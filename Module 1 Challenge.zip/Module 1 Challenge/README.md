# Kickstarting with Excel

## Overview of Project
### Purpose
Louise’s want start crowdfunding campaign to help fund her play “Fever”. She is estimating budget of over $10,000. Through analyze , we will help her to plan choice  date for launch and amount of funding goal for her campaign based on successful campaigns. The purpose of this analyze is to compare and visualize on outcome of other campaigns based on their launch dates and their funding goals and also mirror successful campaigns in same category (theater).

## Analysis and Challenges
### Analysis of Outcomes Based on Launch Date
 Outcome based on launch date discovered trend in May and June seen to be best months to launch campaign. this will help Louise to plan her campaign. it also determines that theater is popular and successful type of campaign overall.
 
 ![This is an image](https://github.com/NadaAdem/kickstarter-analysis/blob/main/Theater_Outcomes_vs_Launch.png)
 
### Analysis of Outcomes Based on Goals
Outcomes based on goals shows that funding goal with less than $5000 is higher chance for successful campaign  than funding  goal with more than $5000 . Besides, funding goal with more than $45000 is higher chance for campaign to fail.

![This is an image](https://github.com/NadaAdem/kickstarter-analysis/blob/main/Outcomes_vs_Goals.png)

### Challenges and Difficulties Encountered
I find it challenge to group column to show the months of the year when analysis  outcome based on launch date. Besides, Analysis of outcomes based on goals will was difficulties to add the goal-amount ranges on the x-axis

## Results
- What are two conclusions you can draw about the Outcomes based on Launch Date?
  1. May and June are the best months to launch campaign relate theatre campaign
  2. Theater is popular and successful type of campaign overall.
- What can you conclude about the Outcomes based on Goals?
    - As Conclusion, analysis of Outcomes based on goals shows that funding  goal with less than $5000 have higher chance for  successful than funding goal  with more than $5000 . Besides, funding goal with  more than $45000 is higher chance for campaign to fail.
- What are some limitations of this dataset?
    - Data hasn’t any data of outcome with canceled result for play category in theater.
- What are some other possible tables and/or graphs that we could create?
   - From analysis of outcomes based on launch date, we can create graph with  filter using last five years to compare it with our graph .
